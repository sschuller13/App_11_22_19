package com.example.myapplication;

import android.support.v7.app.AppCompatActivity;

public class AddInventory extends AppCompatActivity {
}
