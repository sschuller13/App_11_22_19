package com.example.myapplication;

public class Refrence {
        public static final String ServerUrl = "jdbc:jtds:sqlserver://inventorymodule.cletv1tgxreh.us-west-2.rds.amazonaws.com:1433/BotScale Project UIC";
        public static final String ServerId = "botscale3445";
        public static final String ServerPassword = "studenT44$#1";
        public static final String ServerDatabaseUser = "[BotScale Project UIC].dbo.Users";
        public static final String ServerDatabaseInv = "[BotScale Project UIC].dbo.Inventory";
        //public static final String ServerDatabaseCount = "[BotScale Project UIC].dbo.";

}
